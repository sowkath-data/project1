import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

app.use(express.json());

// API route: Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// API route: AI Recruiter Agent Chat
app.post("/api/chat", async (req, res) => {
  const { messages, userProfile } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "Invalid request. 'messages' array is required." });
  }

  try {
    const formattedHistory = messages.map((m: any) => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.text }]
    }));

    // The user's message is the last one in the list
    const lastUserMessage = formattedHistory[formattedHistory.length - 1];
    const previousHistory = formattedHistory.slice(0, -1);

    const systemInstruction = `You are the AI Professional Assistant representing Sowkath Ali.
Sowkath Ali is a Data Scientist and Machine Learning Engineer specializing in predictive modeling, HR analytics, and advanced data visualization.

His Flagship Project is "Employee Attrition Prediction":
- GitHub Repository: https://github.com/sowkath-data/Employee-Attrition-Prediction
- Objective: Predict whether an employee will leave the organization based on various factors (IBM HR Analytics dataset).
- Core Tech Stack: Python, Pandas, NumPy, Scikit-learn, XGBoost, Random Forest, Matplotlib, Seaborn, Jupyter Notebooks.
- Key Metrics: Random Forest (Accuracy: 88.5%, ROC-AUC: 91.2%), XGBoost (Accuracy: 89.2%, ROC-AUC: 92.4%).
- Key Features Analyzed: OverTime (most significant attrition driver), MonthlyIncome, JobRole, Age, StockOptionLevel, YearsAtCompany, JobSatisfaction.
- Feature Engineering: Outlier treatment, robust feature scaling, and addressing class imbalance using SMOTE.

Sowkath's Professional Profile:
- Name: Sowkath Ali (often goes by Sowkath)
- Role: Data Scientist / Machine Learning Engineer
- Contact: sowkath.sow.007@gmail.com
- Location: Dhaka, Bangladesh (Open to remote roles and relocation)
- Skills: Python (Pandas, NumPy, Scikit-Learn, TensorFlow, Keras), SQL, Excel, Git, Tableau, PowerBI, React, Node.js, Express.
- Education: Bachelor of Science in Computer Science and Engineering (CSE).
- Core Strengths: Strong analytical mindset, business-to-technical storytelling, predictive forecasting, deep mathematical understanding of ML models, clean and modular code execution.

Guidelines for your responses:
1. Speak on behalf of Sowkath as his AI Representative or Agent. Keep the tone helpful, professional, highly technical but accessible, and encouraging.
2. Highlight how Sowkath's skills can add business value (e.g., reducing employee turnover costs, forecasting sales, or optimizing data pipelines).
3. Keep answers concise, highly scannable, and structured using clean markdown bullet points where appropriate.
4. If asked about contact info, remind the recruiter they can reach Sowkath directly via his email: sowkath.sow.007@gmail.com.
5. NEVER fabricate professional credentials or experience that are not provided in this prompt. If asked about something unknown, politely offer to have Sowkath follow up via email.`;

    // Start a chat using ai.models.generateContent with standard config or standard chat interface
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [
        { role: 'user', parts: [{ text: systemInstruction }] },
        { role: 'model', parts: [{ text: "Understood. I am Sowkath Ali's AI Professional Representative. I will help recruiters, hiring managers, and visitors understand Sowkath's profile, qualifications, and his flagship Employee Attrition Prediction project." }] },
        ...previousHistory,
        lastUserMessage
      ],
      config: {
        temperature: 0.7,
        maxOutputTokens: 1000,
      }
    });

    const botText = response.text || "I am currently processing that request. Please let me know how else I can assist you with Sowkath's credentials.";
    res.json({ text: botText });

  } catch (error: any) {
    console.error("Gemini API Error in Server:", error);
    res.status(500).json({ 
      error: "Could not retrieve response from AI Representative. Make sure GEMINI_API_KEY is configured in Secrets.",
      details: error.message 
    });
  }
});

// Setup Vite middleware or static serving
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

setupServer();
