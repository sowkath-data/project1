import React from 'react';
import { skillsData } from '../data';
import { CheckCircle, Cpu, BarChart2, Terminal } from 'lucide-react';

export default function Skills() {
  const getIconForCategory = (category: string) => {
    if (category.includes('Machine Learning')) {
      return <Cpu className="w-5 h-5 text-cyan-400" />;
    }
    if (category.includes('Data Engineering')) {
      return <Terminal className="w-5 h-5 text-cyan-400" />;
    }
    return <BarChart2 className="w-5 h-5 text-cyan-400" />;
  };

  return (
    <section id="skills" className="py-20 bg-[#050505] border-t border-[#222222] border-x-[8px] border-b-[8px] border-[#1A1A1A] box-border relative overflow-hidden">
      <div className="absolute top-1/2 left-1/4 w-[400px] h-[400px] bg-cyan-500/5 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16" id="skills-section-header">
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-white tracking-tight uppercase">
            Technical Expertise Matrix
          </h2>
          <div className="text-[10px] uppercase font-mono tracking-[0.2em] text-cyan-400 mt-2 mb-4">ESTABLISHED ABILITIES & PARADIGMS</div>
          <p className="text-gray-400 text-xs sm:text-sm leading-relaxed max-w-xl mx-auto font-display">
            Sowkath's skill-set bridges the gap between deep algorithmic machine learning frameworks, optimized database querying, and full-stack reporting dashboards.
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8" id="skills-grid">
          {skillsData.map((categoryData, idx) => (
            <div
              key={idx}
              className="bg-[#111111] border border-[#222222] rounded-none p-6 hover:border-[#333333] transition-all flex flex-col h-full"
              id={`skills-category-${idx}`}
            >
              {/* Category Header */}
              <div className="flex items-center space-x-3 mb-6 border-b border-[#222222] pb-4">
                <div className="bg-[#050505] p-2 rounded-none border border-[#222222]">
                  {getIconForCategory(categoryData.category)}
                </div>
                <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white">
                  {categoryData.category}
                </h3>
              </div>

              {/* Skills List */}
              <div className="space-y-5 flex-1">
                {categoryData.skills.map((skill, sIdx) => (
                  <div key={sIdx} className="space-y-2">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-gray-300 flex items-center space-x-1.5 uppercase text-[10px] tracking-wider">
                        <CheckCircle className="w-3 h-3 text-cyan-400 inline" />
                        <span>{skill.name}</span>
                      </span>
                      <span className="text-cyan-400 font-bold">{skill.level}%</span>
                    </div>
                    {/* Skill Progress Bar Container */}
                    <div className="h-1.5 w-full bg-[#050505] rounded-none overflow-hidden border border-[#222222]">
                      <div
                        className="h-full bg-cyan-500 rounded-none transition-all duration-1000"
                        style={{ width: `${skill.level}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Core Methodological Highlights */}
        <div className="mt-12 bg-[#111111] border border-[#222222] rounded-none p-6" id="skills-methodologies">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 text-center sm:text-left">
            <div className="space-y-2">
              <span className="text-[10px] font-mono text-cyan-400 block font-bold uppercase tracking-widest">01 / Model Fairness</span>
              <p className="text-xs font-bold uppercase tracking-wider text-white">SMOTE Class Balancer</p>
              <p className="text-[11px] text-gray-400 leading-relaxed">Systematic synthesis of minority class samples to counter critical high attrition class skewing.</p>
            </div>
            <div className="space-y-2">
              <span className="text-[10px] font-mono text-cyan-400 block font-bold uppercase tracking-widest">02 / Explainability</span>
              <p className="text-xs font-bold uppercase tracking-wider text-white">Feature Importance</p>
              <p className="text-[11px] text-gray-400 leading-relaxed">Demystifying deep black-box predictive models with structured permutation feature weight metrics.</p>
            </div>
            <div className="space-y-2">
              <span className="text-[10px] font-mono text-cyan-400 block font-bold uppercase tracking-widest">03 / Engineering</span>
              <p className="text-xs font-bold uppercase tracking-wider text-white">Robust Scale Pipelines</p>
              <p className="text-[11px] text-gray-400 leading-relaxed">Automating numerical outlier clipping, encoding variables, and preventing dataset leaks.</p>
            </div>
            <div className="space-y-2">
              <span className="text-[10px] font-mono text-cyan-400 block font-bold uppercase tracking-widest">04 / Stack Integration</span>
              <p className="text-xs font-bold uppercase tracking-wider text-white">Operational Dashboards</p>
              <p className="text-[11px] text-gray-400 leading-relaxed">Publishing static predictive engines via full-stack responsive web apps, REST APIs, or BI reports.</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
