import React, { useState, useEffect } from 'react';
import { Menu, X, Github, Mail, Sparkles, Brain } from 'lucide-react';
import { portfolioOwner } from '../data';

interface HeaderProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

export default function Header({ activeSection, setActiveSection }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'flagship', label: 'Attrition Project' },
    { id: 'skills', label: 'Technical Skills' },
    { id: 'ai-chat', label: 'AI Representative' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (id: string) => {
    setActiveSection(id);
    setIsMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <header
      id="portfolio-header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b ${
        isScrolled
          ? 'bg-[#050505]/95 backdrop-blur-md border-[#333333] py-3 shadow-lg'
          : 'bg-transparent border-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex flex-col text-left group transition-all"
            id="logo-button"
          >
            <span className="text-[9px] tracking-[0.3em] uppercase text-cyan-500 font-bold mb-0.5">
              Lead ML Engineer / Data Scientist
            </span>
            <span className="font-display font-black text-2xl tracking-tighter text-white">
              SOWKATH<span className="text-cyan-500">.</span>
            </span>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-2" id="desktop-nav">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-3 py-2 text-[11px] uppercase tracking-[0.15em] font-medium transition-all cursor-pointer ${
                  activeSection === item.id
                    ? 'text-cyan-400 font-bold'
                    : 'text-gray-400 hover:text-white'
                }`}
                id={`nav-${item.id}`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Social Links / Call to Action */}
          <div className="hidden lg:flex items-center space-x-3" id="social-links-container">
            <a
              href={portfolioOwner.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 text-gray-400 hover:text-white hover:bg-[#111111] transition-all border border-[#222222]"
              title="GitHub Profile"
              id="header-github"
            >
              <Github className="w-4 h-4" />
            </a>
            <a
              href={`mailto:${portfolioOwner.email}`}
              className="p-2 text-gray-400 hover:text-white hover:bg-[#111111] transition-all border border-[#222222]"
              title="Contact Email"
              id="header-email"
            >
              <Mail className="w-4 h-4" />
            </a>
            <button
              onClick={() => handleNavClick('ai-chat')}
              className="flex items-center space-x-1.5 px-4 py-2 text-[10px] font-black uppercase tracking-wider bg-cyan-500 text-black hover:bg-cyan-400 transition-all cursor-pointer shadow-lg shadow-cyan-500/10"
              id="header-chat-btn"
            >
              <Sparkles className="w-3.5 h-3.5 animate-pulse" />
              <span>Ask Sowkath's AI</span>
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-gray-400 hover:text-white hover:bg-[#111111] transition-colors focus:outline-none"
              aria-label="Toggle Menu"
              id="mobile-menu-toggle"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-[#050505]/95 backdrop-blur-lg border-b border-[#333333]" id="mobile-nav-panel">
          <div className="px-2 pt-2 pb-4 space-y-1 sm:px-3">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`block w-full text-left px-4 py-3 text-xs uppercase tracking-widest font-semibold transition-all ${
                  activeSection === item.id
                    ? 'text-cyan-400 bg-cyan-500/5'
                    : 'text-gray-300 hover:text-white hover:bg-[#111111]'
                }`}
                id={`mobile-nav-${item.id}`}
              >
                {item.label}
              </button>
            ))}
            <div className="pt-4 pb-2 border-t border-[#222222] flex justify-around">
              <a
                href={portfolioOwner.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-2 text-gray-400 hover:text-white px-3 py-2 text-xs uppercase tracking-wider"
                id="mobile-nav-github"
              >
                <Github className="w-4 h-4" />
                <span>GitHub</span>
              </a>
              <a
                href={`mailto:${portfolioOwner.email}`}
                className="flex items-center space-x-2 text-gray-400 hover:text-white px-3 py-2 text-xs uppercase tracking-wider"
                id="mobile-nav-email"
              >
                <Mail className="w-4 h-4" />
                <span>Email</span>
              </a>
            </div>
            <button
              onClick={() => handleNavClick('ai-chat')}
              className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-cyan-500 text-black font-black uppercase tracking-wider text-xs"
              id="mobile-nav-chat"
            >
              <Sparkles className="w-4 h-4" />
              <span>Ask Sowkath's AI Representative</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
