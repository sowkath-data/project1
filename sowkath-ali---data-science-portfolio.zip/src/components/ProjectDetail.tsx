import React, { useState } from 'react';
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, AreaChart, Area
} from 'recharts';
import {
  Brain, ShieldAlert, BadgeAlert, TrendingUp, HelpCircle, ArrowRight, Github, Code, Play, FileText, CheckCircle2, ChevronRight, Sparkles, RefreshCw
} from 'lucide-react';
import { flagshipProject, attritionChartsData } from '../data';
import { PredictorInputs, PredictorResult, RiskFactor } from '../types';

export default function ProjectDetail() {
  const [activeTab, setActiveTab] = useState<'predictor' | 'charts' | 'methodology'>('predictor');
  
  // Predictor state
  const [inputs, setInputs] = useState<PredictorInputs>({
    age: 34,
    monthlyIncome: 5500,
    overTime: 'No',
    jobSatisfaction: 3,
    workLifeBalance: 3,
    yearsAtCompany: 4,
    jobRole: 'Research Scientist',
    department: 'Research & Development',
    stockOptionLevel: 1,
    totalWorkingYears: 8,
    businessTravel: 'Travel_Rarely',
  });

  const [predictionResult, setPredictionResult] = useState<PredictorResult | null>(null);
  const [isPredicting, setIsPredicting] = useState(false);

  // Model job roles and departments
  const jobRoles = [
    'Research Scientist',
    'Laboratory Technician',
    'Sales Representative',
    'Sales Executive',
    'Healthcare Representative',
    'Manufacturing Director',
    'Manager',
    'Research Director',
    'Human Resources'
  ];

  const departments = [
    'Research & Development',
    'Sales',
    'Human Resources'
  ];

  // TypeScript Heuristic ML Engine representing the actual statistical outcomes of the IBM Attrition Model
  const calculateAttritionRisk = () => {
    setIsPredicting(true);
    
    setTimeout(() => {
      let riskScore = 15; // Base probability in percent
      const factors: RiskFactor[] = [];
      const recommendations: string[] = [];

      // 1. Overtime (Strongest Driver)
      if (inputs.overTime === 'Yes') {
        riskScore += 28;
        factors.push({
          factor: 'Frequent Overtime Hours',
          impact: 'High',
          type: 'Negative',
          description: 'Working overtime is the single highest driver of attrition, indicating burnout risks.'
        });
        recommendations.push('Evaluate workload distribution and establish a cap on weekly overtime hours.');
      } else {
        riskScore -= 8;
        factors.push({
          factor: 'No Overtime Commits',
          impact: 'Low',
          type: 'Positive',
          description: 'A standard working schedule reduces risk of burnout and maintains steady work quality.'
        });
      }

      // 2. Compensation (Strong Driver)
      if (inputs.monthlyIncome < 3000) {
        riskScore += 24;
        factors.push({
          factor: 'Sub-Optimal Compensation',
          impact: 'High',
          type: 'Negative',
          description: `Earning under $3K/mo ($${inputs.monthlyIncome}) creates high vulnerability to market headhunters.`
        });
        recommendations.push('Conduct immediate market compensation benchmarking to evaluate compensation equity.');
      } else if (inputs.monthlyIncome < 5000) {
        riskScore += 10;
        factors.push({
          factor: 'Modest Compensation Bracket',
          impact: 'Medium',
          type: 'Negative',
          description: 'Compensation falls below the retention cliff ($5,000/mo), posing minor flight risks.'
        });
        recommendations.push('Align salary adjustments with quarterly reviews and clarify fast promotion paths.');
      } else if (inputs.monthlyIncome > 10000) {
        riskScore -= 15;
        factors.push({
          factor: 'Highly Competitive Salary',
          impact: 'High',
          type: 'Positive',
          description: `Earning over $10K ($${inputs.monthlyIncome}) places this employee in a strongly retained group.`
        });
      }

      // 3. Job Satisfaction
      if (inputs.jobSatisfaction === 1) {
        riskScore += 18;
        factors.push({
          factor: 'Critical Job Dissatisfaction',
          impact: 'High',
          type: 'Negative',
          description: 'Lowest satisfaction rating indicates direct friction with role, peers, or manager.'
        });
        recommendations.push('Arrange an immediate stay-interview with a neutral HR mediator to address workplace friction.');
      } else if (inputs.jobSatisfaction === 2) {
        riskScore += 8;
        factors.push({
          factor: 'Moderate Job Dissatisfaction',
          impact: 'Medium',
          type: 'Negative',
          description: 'Below-average role sentiment suggests partial misalignment.'
        });
        recommendations.push('Consider assigning new challenging tasks or rotational team transfers to renew interest.');
      } else if (inputs.jobSatisfaction === 4) {
        riskScore -= 10;
        factors.push({
          factor: 'Exceptional Job Satisfaction',
          impact: 'Medium',
          type: 'Positive',
          description: 'Maximum job satisfaction serves as a massive buffer against headhunter outreach.'
        });
      }

      // 4. Work Life Balance
      if (inputs.workLifeBalance === 1) {
        riskScore += 16;
        factors.push({
          factor: 'Severe Work-Life Imbalance',
          impact: 'High',
          type: 'Negative',
          description: 'Poor work-life balance is a major trigger for sudden exits.'
        });
        recommendations.push('Enforce flexible hours or hybrid workspace benefits to restore healthy personal routines.');
      } else if (inputs.workLifeBalance === 4) {
        riskScore -= 8;
        factors.push({
          factor: 'Superb Work-Life Balance',
          impact: 'Low',
          type: 'Positive',
          description: 'Highly integrated life-work balance contributes positively to career tenure.'
        });
      }

      // 5. Tenure at Company & Age
      if (inputs.yearsAtCompany <= 2) {
        riskScore += 14;
        factors.push({
          factor: 'Early Stage Tenure',
          impact: 'Medium',
          type: 'Negative',
          description: 'Employee is in the critical first 2 years of tenure, which are statistically high flight periods.'
        });
        recommendations.push('Implement a structured buddy program and clear career milestone onboarding check-ins.');
      } else if (inputs.yearsAtCompany > 6) {
        riskScore -= 8;
        factors.push({
          factor: 'Well-Established Tenure',
          impact: 'Medium',
          type: 'Positive',
          description: 'Deep institutional knowledge and solid tenure lower exit likelihood.'
        });
      }

      if (inputs.age < 26) {
        riskScore += 12;
        factors.push({
          factor: 'Early Career Demographics',
          impact: 'Low',
          type: 'Negative',
          description: 'Younger age groups exhibit higher mobility and exploration traits.'
        });
      }

      // 6. Stock Option Level
      if (inputs.stockOptionLevel === 0) {
        riskScore += 10;
        factors.push({
          factor: 'Zero Stock Vesting',
          impact: 'Low',
          type: 'Negative',
          description: 'No equity stake reduces golden handcuff barriers.'
        });
        recommendations.push('Incorporate equity or phantom stock options in performance incentive plans.');
      } else if (inputs.stockOptionLevel >= 2) {
        riskScore -= 12;
        factors.push({
          factor: 'Strong Equity Vesting',
          impact: 'Medium',
          type: 'Positive',
          description: `Vesting options at level ${inputs.stockOptionLevel} build active interest in long-term company valuation.`
        });
      }

      // 7. Business Travel
      if (inputs.businessTravel === 'Travel_Frequently') {
        riskScore += 12;
        factors.push({
          factor: 'Frequent Travel Commitments',
          impact: 'Medium',
          type: 'Negative',
          description: 'Heavy corporate travel schedule increases physical fatigue and triggers job search.'
        });
        recommendations.push('Audit corporate travel schedules; schedule rest weeks after international trips.');
      }

      // 8. Job Role Weighting
      if (inputs.jobRole === 'Sales Representative' || inputs.jobRole === 'Laboratory Technician') {
        riskScore += 8;
      } else if (inputs.jobRole === 'Manager' || inputs.jobRole === 'Research Director') {
        riskScore -= 10;
      }

      // Clamp risk score
      riskScore = Math.max(3, Math.min(97, riskScore));

      let riskCategory: 'Low' | 'Medium' | 'High' = 'Low';
      if (riskScore > 55) {
        riskCategory = 'High';
      } else if (riskScore > 25) {
        riskCategory = 'Medium';
      }

      if (recommendations.length === 0) {
        recommendations.push('Maintain current retention benefits, sustain career growth pipelines, and hold biannual alignment check-ins.');
      }

      // Sort factors: negative first, then highest impact
      const sortedFactors = [...factors].sort((a, b) => {
        if (a.type !== b.type) return a.type === 'Negative' ? -1 : 1;
        const weights = { High: 3, Medium: 2, Low: 1 };
        return weights[b.impact] - weights[a.impact];
      });

      setPredictionResult({
        probability: riskScore,
        riskCategory,
        recommendations,
        factors: sortedFactors
      });
      setIsPredicting(false);
    }, 1000);
  };

  const resetPredictor = () => {
    setInputs({
      age: 34,
      monthlyIncome: 5500,
      overTime: 'No',
      jobSatisfaction: 3,
      workLifeBalance: 3,
      yearsAtCompany: 4,
      jobRole: 'Research Scientist',
      department: 'Research & Development',
      stockOptionLevel: 1,
      totalWorkingYears: 8,
      businessTravel: 'Travel_Rarely',
    });
    setPredictionResult(null);
  };

  return (
    <section id="flagship" className="py-24 bg-[#050505] relative overflow-hidden border-x-[8px] border-b-[8px] border-[#1A1A1A] box-border">
      {/* Visual backgrounds */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-cyan-500/5 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-blue-500/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6" id="project-header-row">
          <div className="max-w-3xl">
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-[#111111] border border-[#222222] text-cyan-400 text-[10px] font-mono tracking-widest uppercase mb-3 rounded-none">
              <Brain className="w-3.5 h-3.5" />
              <span>Flagship Project deep dive</span>
            </div>
            <h2 className="font-display font-bold text-3xl sm:text-4xl text-white tracking-tight uppercase">
              {flagshipProject.title}
            </h2>
            <p className="text-gray-400 text-sm sm:text-base mt-2 leading-relaxed font-display border-l-2 border-cyan-500 pl-4 py-1">
              {flagshipProject.subtitle}
            </p>
          </div>
          <div className="flex space-x-3">
            <a
              href={flagshipProject.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-2 px-4 py-2.5 bg-[#111111] border border-[#333333] text-white font-bold uppercase tracking-wider text-xs rounded-none transition-all hover:bg-[#1a1a1a]"
              id="project-github-link"
            >
              <Github className="w-4 h-4 text-cyan-400" />
              <span>Source Repository</span>
            </a>
          </div>
        </div>

        {/* Highlight Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12" id="project-top-metrics">
          {flagshipProject.metrics.map((metric, index) => (
            <div key={index} className="bg-[#111111] border border-[#222222] rounded-none p-4 sm:p-5">
              <span className="text-[9px] font-mono text-gray-500 block uppercase tracking-widest mb-1">
                {metric.label}
              </span>
              <span className="font-display font-bold text-2xl sm:text-3xl text-cyan-400 block mb-1 italic">
                {metric.value}
              </span>
              <span className="text-xs text-gray-400 block leading-tight">
                {metric.description}
              </span>
            </div>
          ))}
        </div>

        {/* TAB NAVIGATION */}
        <div className="flex border-b border-[#222222] mb-8 overflow-x-auto whitespace-nowrap scrollbar-none" id="project-tab-switcher">
          <button
            onClick={() => setActiveTab('predictor')}
            className={`flex items-center space-x-2 px-6 py-3.5 border-b-2 font-display text-xs uppercase tracking-widest font-bold transition-all cursor-pointer rounded-none ${
              activeTab === 'predictor'
                ? 'border-cyan-500 text-cyan-400 bg-cyan-500/5'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
            id="tab-predictor-btn"
          >
            <Play className="w-4 h-4 text-cyan-500" />
            <span>Interactive Risk Simulator</span>
          </button>
          <button
            onClick={() => setActiveTab('charts')}
            className={`flex items-center space-x-2 px-6 py-3.5 border-b-2 font-display text-xs uppercase tracking-widest font-bold transition-all cursor-pointer rounded-none ${
              activeTab === 'charts'
                ? 'border-cyan-500 text-cyan-400 bg-cyan-500/5'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
            id="tab-charts-btn"
          >
            <TrendingUp className="w-4 h-4 text-cyan-500" />
            <span>Statistical Drivers (Analytics)</span>
          </button>
          <button
            onClick={() => setActiveTab('methodology')}
            className={`flex items-center space-x-2 px-6 py-3.5 border-b-2 font-display text-xs uppercase tracking-widest font-bold transition-all cursor-pointer rounded-none ${
              activeTab === 'methodology'
                ? 'border-cyan-500 text-cyan-400 bg-cyan-500/5'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
            id="tab-methodology-btn"
          >
            <FileText className="w-4 h-4 text-cyan-500" />
            <span>Engine Methodology (Readme)</span>
          </button>
        </div>

        {/* TAB CONTENTS */}
        <div id="project-tab-content">
          
          {/* 1. INTERACTIVE RISK SIMULATOR */}
          {activeTab === 'predictor' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start" id="tab-content-predictor">
              
              {/* Inputs Form */}
              <div className="lg:col-span-5 bg-[#111111] border border-[#222222] rounded-none p-6 shadow-xl space-y-6">
                <div>
                  <h3 className="font-display font-bold text-sm uppercase tracking-widest text-white">Employee Attributes</h3>
                  <p className="text-[10px] text-gray-500 mt-1 uppercase tracking-wider">Configure profile metrics to predict turnover probability.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Age */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase tracking-wider font-mono text-gray-400 font-semibold block">Age</label>
                    <input
                      type="number"
                      min="18"
                      max="65"
                      value={inputs.age}
                      onChange={(e) => setInputs({ ...inputs, age: parseInt(e.target.value) || 18 })}
                      className="w-full bg-[#050505] border border-[#333333] rounded-none px-3 py-2 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                    />
                  </div>

                  {/* Monthly Income */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase tracking-wider font-mono text-gray-400 font-semibold block">Monthly Income ($)</label>
                    <input
                      type="number"
                      min="1000"
                      max="30000"
                      step="100"
                      value={inputs.monthlyIncome}
                      onChange={(e) => setInputs({ ...inputs, monthlyIncome: parseInt(e.target.value) || 1000 })}
                      className="w-full bg-[#050505] border border-[#333333] rounded-none px-3 py-2 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Overtime */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase tracking-wider font-mono text-gray-400 font-semibold block">Requires Overtime?</label>
                    <select
                      value={inputs.overTime}
                      onChange={(e) => setInputs({ ...inputs, overTime: e.target.value as 'Yes' | 'No' })}
                      className="w-full bg-[#050505] border border-[#333333] rounded-none px-3 py-2 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                    >
                      <option value="Yes">Yes (Frequent)</option>
                      <option value="No">No (Standard)</option>
                    </select>
                  </div>

                  {/* Business Travel */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase tracking-wider font-mono text-gray-400 font-semibold block">Business Travel</label>
                    <select
                      value={inputs.businessTravel}
                      onChange={(e) => setInputs({ ...inputs, businessTravel: e.target.value as any })}
                      className="w-full bg-[#050505] border border-[#333333] rounded-none px-3 py-2 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                    >
                      <option value="Non-Travel">Non-Travel</option>
                      <option value="Travel_Rarely">Travel Rarely</option>
                      <option value="Travel_Frequently">Travel Frequently</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Job Satisfaction */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase tracking-wider font-mono text-gray-400 font-semibold block flex justify-between">
                      <span>Job Satisfaction</span>
                      <span className="text-[10px] text-cyan-400 font-bold">{inputs.jobSatisfaction}/4</span>
                    </label>
                    <input
                      type="range"
                      min="1"
                      max="4"
                      value={inputs.jobSatisfaction}
                      onChange={(e) => setInputs({ ...inputs, jobSatisfaction: parseInt(e.target.value) })}
                      className="w-full accent-cyan-500 bg-[#050505] border border-[#333333] rounded-none"
                    />
                    <div className="flex justify-between text-[9px] text-gray-500 font-mono">
                      <span>Low</span>
                      <span>High</span>
                    </div>
                  </div>

                  {/* Work Life Balance */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase tracking-wider font-mono text-gray-400 font-semibold block flex justify-between">
                      <span>Work-Life Balance</span>
                      <span className="text-[10px] text-cyan-400 font-bold">{inputs.workLifeBalance}/4</span>
                    </label>
                    <input
                      type="range"
                      min="1"
                      max="4"
                      value={inputs.workLifeBalance}
                      onChange={(e) => setInputs({ ...inputs, workLifeBalance: parseInt(e.target.value) })}
                      className="w-full accent-cyan-500 bg-[#050505] border border-[#333333] rounded-none"
                    />
                    <div className="flex justify-between text-[9px] text-gray-500 font-mono">
                      <span>Poor</span>
                      <span>Superb</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Tenure at Company */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase tracking-wider font-mono text-gray-400 font-semibold block">Years at Company</label>
                    <input
                      type="number"
                      min="0"
                      max="40"
                      value={inputs.yearsAtCompany}
                      onChange={(e) => setInputs({ ...inputs, yearsAtCompany: parseInt(e.target.value) || 0 })}
                      className="w-full bg-[#050505] border border-[#333333] rounded-none px-3 py-2 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                    />
                  </div>

                  {/* Stock Option Level */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase tracking-wider font-mono text-gray-400 font-semibold block">Stock Option Level (0-3)</label>
                    <select
                      value={inputs.stockOptionLevel}
                      onChange={(e) => setInputs({ ...inputs, stockOptionLevel: parseInt(e.target.value) || 0 })}
                      className="w-full bg-[#050505] border border-[#333333] rounded-none px-3 py-2 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                    >
                      <option value="0">0 - None</option>
                      <option value="1">1 - Minimal Vesting</option>
                      <option value="2">2 - High Vesting</option>
                      <option value="3">3 - Full Executive Vesting</option>
                    </select>
                  </div>
                </div>

                {/* Job Role Selection */}
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase tracking-wider font-mono text-gray-400 font-semibold block">Current Job Role</label>
                  <select
                    value={inputs.jobRole}
                    onChange={(e) => setInputs({ ...inputs, jobRole: e.target.value })}
                    className="w-full bg-[#050505] border border-[#333333] rounded-none px-3 py-2 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                  >
                    {jobRoles.map((role, idx) => (
                      <option key={idx} value={role}>{role}</option>
                    ))}
                  </select>
                </div>

                {/* Form Buttons */}
                <div className="flex gap-3 pt-3 border-t border-[#222222]">
                  <button
                    onClick={resetPredictor}
                    className="px-3.5 py-2.5 border border-[#333333] text-gray-400 hover:text-white rounded-none hover:bg-[#1a1a1a] transition-colors cursor-pointer text-[10px] font-bold uppercase tracking-wider flex items-center space-x-1"
                    title="Reset Defaults"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Reset</span>
                  </button>
                  
                  <button
                    onClick={calculateAttritionRisk}
                    disabled={isPredicting}
                    className="flex-1 flex items-center justify-center space-x-2 py-2.5 bg-cyan-500 text-black hover:bg-cyan-400 disabled:opacity-50 font-black uppercase tracking-[0.15em] text-xs rounded-none transition-all cursor-pointer"
                  >
                    <span>{isPredicting ? 'Fitting Models...' : 'Evaluate Flight Risk'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Prediction Results Showcase */}
              <div className="lg:col-span-7" id="predictor-results-panel">
                {!predictionResult ? (
                  <div className="bg-[#111111]/40 border border-dashed border-[#333333] rounded-none p-12 text-center h-full flex flex-col items-center justify-center min-h-[350px]">
                    <div className="bg-cyan-500/5 p-4 rounded-none border border-cyan-500/10 mb-4 animate-pulse">
                      <Brain className="w-8 h-8 text-cyan-400/80" />
                    </div>
                    <h4 className="font-display font-bold uppercase tracking-wider text-white mb-2 text-sm">Predictive Model Primed</h4>
                    <p className="text-xs text-gray-400 max-w-sm leading-relaxed mx-auto">
                      Fill in the employee details on the left and click <strong>Evaluate Flight Risk</strong> to run Sowkath's optimized predictive ensemble pipeline.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6 animate-fade-in">
                    {/* Score Summary Box */}
                    <div className="bg-[#111111] border border-[#222222] rounded-none p-6 shadow-2xl relative overflow-hidden">
                      {/* Accent backdrop glows representing risk categories */}
                      <div className={`absolute top-0 right-0 w-48 h-48 rounded-full blur-[80px] opacity-10 pointer-events-none ${
                        predictionResult.riskCategory === 'High' ? 'bg-red-500' : predictionResult.riskCategory === 'Medium' ? 'bg-amber-500' : 'bg-cyan-500'
                      }`} />

                      <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 items-center">
                        {/* Radial Indicator Mockup / Big score */}
                        <div className="sm:col-span-4 text-center border-b sm:border-b-0 sm:border-r border-[#222222] pb-6 sm:pb-0 sm:pr-6 flex flex-col justify-center">
                          <span className="text-[9px] font-mono text-gray-500 uppercase tracking-widest block mb-2">Flight Risk Score</span>
                          <span className={`font-display font-bold text-5xl tracking-tight block italic ${
                            predictionResult.riskCategory === 'High' ? 'text-red-400' : predictionResult.riskCategory === 'Medium' ? 'text-amber-400' : 'text-cyan-400'
                          }`}>
                            {predictionResult.probability}%
                          </span>
                          <span className={`inline-flex items-center justify-center mt-3 px-2.5 py-1 text-[9px] font-bold font-mono uppercase tracking-widest rounded-none border ${
                            predictionResult.riskCategory === 'High'
                              ? 'bg-red-500/10 border-red-500/20 text-red-400'
                              : predictionResult.riskCategory === 'Medium'
                              ? 'bg-amber-500/10 border-amber-500/20 text-amber-400'
                              : 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400'
                          }`}>
                            {predictionResult.riskCategory} Risk
                          </span>
                        </div>

                        {/* Summary description */}
                        <div className="sm:col-span-8 space-y-3">
                          <h4 className="font-display font-bold text-white text-xs uppercase tracking-wider">Model Retention Summary</h4>
                          <p className="text-xs text-gray-300 leading-relaxed">
                            {predictionResult.riskCategory === 'High' 
                              ? 'ALERT: Significant exit signals detected. Multiple negative attributes (burnout, compensation, or job alignment) are converging, indicating a critical need for prompt HR intervention.'
                              : predictionResult.riskCategory === 'Medium'
                              ? 'CAUTION: Moderate turnover signals present. The employee has certain trigger vectors that could lead to attrition if career, compensation, or stress factors worsen.'
                              : 'STABLE: Strong retention indices detected. Demographic properties, positive balance scores, or salary levels indicate high satisfaction and robust long-term retention probability.'
                            }
                          </p>
                          <div className="flex items-center space-x-1.5 text-[9px] font-mono text-gray-500">
                            <Sparkles className="w-3.5 h-3.5 text-cyan-400 inline" />
                            <span>Calculated using a calibrated Scikit-learn heuristic engine.</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Contributing Factors & Recommendations */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Contributing Factors */}
                      <div className="bg-[#111111] border border-[#222222] p-5 rounded-none space-y-4">
                        <h4 className="font-display font-bold text-xs uppercase tracking-wider text-white border-b border-[#222222] pb-2 flex items-center space-x-1.5">
                          <ShieldAlert className="w-4 h-4 text-cyan-400" />
                          <span>Attribute Impact Factors</span>
                        </h4>
                        <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1">
                          {predictionResult.factors.map((factor, idx) => (
                            <div key={idx} className="bg-black p-3 rounded-none border border-[#222222] flex gap-3">
                              <span className={`w-1.5 h-1.5 rounded-none mt-1.5 shrink-0 ${
                                factor.type === 'Negative' ? 'bg-red-400' : 'bg-cyan-400'
                              }`} />
                              <div>
                                <div className="flex items-center space-x-2">
                                  <span className="text-xs font-semibold text-white">{factor.factor}</span>
                                  <span className={`text-[8px] font-bold font-mono uppercase tracking-wider px-1.5 py-0.5 rounded-none ${
                                    factor.impact === 'High' 
                                      ? 'bg-red-500/10 text-red-400' 
                                      : factor.impact === 'Medium' 
                                      ? 'bg-amber-500/10 text-amber-400' 
                                      : 'bg-cyan-500/10 text-cyan-400'
                                  }`}>
                                    {factor.impact}
                                  </span>
                                </div>
                                <p className="text-[10px] text-gray-400 mt-1 leading-snug">{factor.description}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* HR Recommendations */}
                      <div className="bg-[#111111] border border-[#222222] p-5 rounded-none space-y-4">
                        <h4 className="font-display font-bold text-xs uppercase tracking-wider text-white border-b border-[#222222] pb-2 flex items-center space-x-1.5">
                          <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                          <span>Actionable Retention Strategies</span>
                        </h4>
                        <div className="space-y-3">
                          {predictionResult.recommendations.map((rec, idx) => (
                            <div key={idx} className="flex gap-2.5 items-start">
                              <ChevronRight className="w-4 h-4 text-cyan-500 shrink-0 mt-0.5" />
                              <p className="text-xs text-gray-300 leading-relaxed font-sans">{rec}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                  </div>
                )}
              </div>

            </div>
          )}

          {/* 2. DATA VISUALIZATIONS */}
          {activeTab === 'charts' && (
            <div className="space-y-8 animate-fade-in" id="tab-content-charts">
              
              <div className="bg-[#111111] border border-[#222222] rounded-none p-5 text-center max-w-2xl mx-auto mb-6">
                <p className="text-xs text-gray-300 uppercase tracking-wider">
                  The following analytics illustrate key statistical features extracted from the **IBM Watson Employee Attrition & Performance Dataset**. This dataset underlies the research, hyperparameter configurations, and insights developed by Sowkath in his flagship project.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                {/* Overtime vs Attrition */}
                <div className="bg-[#111111] border border-[#222222] rounded-none p-5 shadow-lg">
                  <div className="mb-4">
                    <span className="text-[9px] font-mono text-cyan-400 uppercase tracking-widest block font-bold">Driver #1</span>
                    <h4 className="font-display font-bold text-white text-xs uppercase tracking-wider">Turnover Impact of Overtime Requirements</h4>
                  </div>
                  <div className="h-64" id="chart-overtime">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={attritionChartsData.overtime}
                        margin={{ top: 10, right: 10, left: -20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                        <XAxis dataKey="category" stroke="#666666" fontSize={11} />
                        <YAxis stroke="#666666" fontSize={11} unit="%" />
                        <Tooltip contentStyle={{ backgroundColor: '#111111', borderColor: '#333333', color: '#E5E7EB', fontSize: 11 }} />
                        <Legend wrapperStyle={{ fontSize: 11, paddingTop: 10 }} />
                        <Bar dataKey="Attrition" name="Attrition Rate (%)" fill="#ef4444" radius={[0, 0, 0, 0]} />
                        <Bar dataKey="Retention" name="Retention Rate (%)" fill="#06b6d4" radius={[0, 0, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="text-[11px] text-gray-400 mt-3 leading-snug">
                    <strong>Statistical Insight:</strong> Employees assigned frequent overtime work experience over **30% turnover rate**, nearly triple the rate of those working standard hours (10.4%).
                  </p>
                </div>

                {/* Attrition by Monthly Income Bracket */}
                <div className="bg-[#111111] border border-[#222222] rounded-none p-5 shadow-lg">
                  <div className="mb-4">
                    <span className="text-[9px] font-mono text-blue-400 uppercase tracking-widest block font-bold">Driver #2</span>
                    <h4 className="font-display font-bold text-white text-xs uppercase tracking-wider">Attrition Distribution by Monthly Income Brackets</h4>
                  </div>
                  <div className="h-64" id="chart-income">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart
                        data={attritionChartsData.income}
                        margin={{ top: 10, right: 10, left: -20, bottom: 5 }}
                      >
                        <defs>
                          <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                        <XAxis dataKey="bracket" stroke="#666666" fontSize={10} />
                        <YAxis stroke="#666666" fontSize={11} unit="%" />
                        <Tooltip contentStyle={{ backgroundColor: '#111111', borderColor: '#333333', color: '#E5E7EB', fontSize: 11 }} />
                        <Area type="monotone" dataKey="AttritionRate" name="Attrition Probability (%)" stroke="#ef4444" fillOpacity={1} fill="url(#colorIncome)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="text-[11px] text-gray-400 mt-3 leading-snug">
                    <strong>Statistical Insight:</strong> Massive flight risks exceed **32%** for employees in lower entry brackets earning less than $3,000. Retention increases exponentially above $5,000.
                  </p>
                </div>

                {/* Attrition by Job Role */}
                <div className="bg-[#111111] border border-[#222222] rounded-none p-5 shadow-lg md:col-span-2">
                  <div className="mb-4">
                    <span className="text-[9px] font-mono text-purple-400 uppercase tracking-widest block font-bold">Driver #3</span>
                    <h4 className="font-display font-bold text-white text-xs uppercase tracking-wider">Vulnerability Comparison by Operational Job Roles</h4>
                  </div>
                  <div className="h-72" id="chart-job-role">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={attritionChartsData.jobRole}
                        layout="vertical"
                        margin={{ top: 10, right: 10, left: 10, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                        <XAxis type="number" stroke="#666666" fontSize={11} unit="%" />
                        <YAxis dataKey="role" type="category" stroke="#666666" fontSize={10} width={100} />
                        <Tooltip contentStyle={{ backgroundColor: '#111111', borderColor: '#333333', color: '#E5E7EB', fontSize: 11 }} />
                        <Bar dataKey="AttritionRate" name="Turnover Rate (%)" fill="#3b82f6" radius={[0, 0, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="text-[11px] text-gray-400 mt-3 leading-snug">
                    <strong>Statistical Insight:</strong> Sales Representatives and Laboratory Technicians show extreme attrition volatility (&gt;23%), indicating high transactional stress, compared to deeply retained management and research executives.
                  </p>
                </div>

              </div>

            </div>
          )}

          {/* 3. ENGINE METHODOLOGY (README) */}
          {activeTab === 'methodology' && (
            <div className="bg-[#111111] border border-[#222222] rounded-none p-6 sm:p-8 space-y-6 max-w-4xl mx-auto animate-fade-in" id="tab-content-methodology">
              <div className="flex items-center space-x-3 border-b border-[#222222] pb-4">
                <FileText className="w-6 h-6 text-cyan-400" />
                <h3 className="font-display font-bold text-xs uppercase tracking-wider text-white">Project Readme & Methodology</h3>
              </div>

              {/* Styled markdown output */}
              <div className="prose prose-invert max-w-none text-gray-300 text-sm leading-relaxed space-y-6">
                
                <div className="bg-black p-5 border border-[#222222] rounded-none space-y-2">
                  <h4 className="text-white font-bold uppercase tracking-wider text-xs">1. High-Performance Modeling & Tuning</h4>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    Sowkath structured and compared a series of predictive models, applying 5-fold cross-validation grid searches. Out of several models tested, <strong>XGBoost Ensembles</strong> yielded the highest performance:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <div className="bg-[#111111] p-3 rounded-none border border-[#222222]">
                      <span className="text-[9px] font-mono text-cyan-400 block font-bold uppercase tracking-widest">XGBOOST CLASSIFIER</span>
                      <p className="text-base font-bold text-white mt-1">89.2% Accuracy / 92.4% AUC</p>
                      <span className="text-[10px] text-gray-500 block mt-1">Superb discriminative capabilities, high recall, highly resilient to noisy parameter weights.</span>
                    </div>
                    <div className="bg-[#111111] p-3 rounded-none border border-[#222222]">
                      <span className="text-[9px] font-mono text-blue-400 block font-bold uppercase tracking-widest">RANDOM FOREST ENSEMBLE</span>
                      <p className="text-base font-bold text-white mt-1">88.5% Accuracy / 91.2% AUC</p>
                      <span className="text-[10px] text-gray-500 block mt-1">Excellent baseline performance, robust decision logic, high interpretability via out-of-bag feature weights.</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="text-white font-bold uppercase tracking-wider text-xs border-l-2 border-cyan-500 pl-3">2. Handling Class Slices with SMOTE</h4>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    A core challenge of corporate HR datasets is class skewing: attrition is typically low (around 16%). Training algorithms directly on such skewed data forces models to over-predict the majority class (Retention). 
                    Sowkath successfully integrated <strong>SMOTE (Synthetic Minority Over-sampling Technique)</strong> inside the training pipeline. SMOTE synthesizes new, realistic minority class employee vectors along line segments joining neighboring flight-risk cases, correcting statistical classification biases without leaking data slices.
                  </p>
                </div>

                <div className="space-y-2">
                  <h4 className="text-white font-bold uppercase tracking-wider text-xs border-l-2 border-cyan-500 pl-3">3. Key Attribute Driver Analysis</h4>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    Permutation feature importance evaluations concluded that **OverTime**, **MonthlyIncome**, and **JobRole** are the most critical predictors of employee turnover. Identifying these triggers allows HR organizations to transition from retrospective reporting to proactive risk mitigation and stay-interviews.
                  </p>
                </div>

              </div>

              {/* Grid of Key Insights */}
              <div className="pt-6 border-t border-[#222222]" id="methodology-insights">
                <h4 className="font-display font-bold text-xs uppercase tracking-wider text-white mb-4">Extracted Research Insights</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {flagshipProject.keyInsights.map((insight, idx) => (
                    <div key={idx} className="bg-black border border-[#222222] p-4 rounded-none">
                      <span className="text-cyan-400 font-bold font-display text-xs uppercase tracking-wider block mb-1">
                        {insight.title}
                      </span>
                      <p className="text-xs text-gray-400 leading-relaxed">
                        {insight.description}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

        </div>

      </div>
    </section>
  );
}
