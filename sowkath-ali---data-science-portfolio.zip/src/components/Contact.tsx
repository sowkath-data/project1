import React, { useState } from 'react';
import { Mail, MapPin, Github, Send, Sparkles, CheckCircle, Linkedin } from 'lucide-react';
import { portfolioOwner } from '../data';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setFormData({ name: '', email: '', company: '', message: '' });
    }, 1200);
  };

  return (
    <section id="contact" className="py-24 bg-[#050505] border-t border-[#222222] border-x-[8px] border-b-[8px] border-[#1A1A1A] box-border relative">
      <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] bg-cyan-500/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16" id="contact-section-header">
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-white tracking-tight uppercase">
            Get in <span className="text-cyan-400 italic font-mono">Touch</span>
          </h2>
          <div className="text-[10px] uppercase font-mono tracking-[0.2em] text-cyan-400 mt-2 mb-4">DIRECT CORRESPONDENCE & RECRUITING</div>
          <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">
            Interested in hiring Sowkath Ali, collaborating on data science research, or discussing employee attrition patterns? Drop a message below.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start" id="contact-grid">
          
          {/* Contact Details Card */}
          <div className="lg:col-span-5 space-y-6" id="contact-info-panel">
            <div className="bg-[#111111] border border-[#222222] rounded-none p-6 shadow-xl space-y-6">
              <h3 className="font-display font-bold text-xs uppercase tracking-wider text-white">Direct Information</h3>
              
              <div className="space-y-4">
                
                {/* Email Option */}
                <a
                  href={`mailto:${portfolioOwner.email}`}
                  className="flex items-start space-x-4 p-4 rounded-none bg-black border border-[#222222] hover:border-cyan-500/50 transition-all group"
                  id="contact-email-link"
                >
                  <div className="p-2.5 bg-cyan-500/10 rounded-none border border-cyan-500/20 text-cyan-400 group-hover:bg-cyan-500/20 transition-colors">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider block">Send direct email</span>
                    <span className="text-xs font-mono font-bold text-white mt-1 block">{portfolioOwner.email}</span>
                  </div>
                </a>

                {/* Location */}
                <div className="flex items-start space-x-4 p-4 rounded-none bg-black border border-[#222222]" id="contact-location">
                  <div className="p-2.5 bg-cyan-500/10 rounded-none border border-cyan-500/20 text-cyan-400">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider block">Office Location</span>
                    <span className="text-xs font-mono font-bold text-white mt-1 block">{portfolioOwner.location}</span>
                  </div>
                </div>

                {/* GitHub Option */}
                <a
                  href={portfolioOwner.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start space-x-4 p-4 rounded-none bg-black border border-[#222222] hover:border-cyan-500/50 transition-all group"
                  id="contact-github-link"
                >
                  <div className="p-2.5 bg-cyan-500/10 rounded-none border border-cyan-500/20 text-cyan-400 group-hover:bg-cyan-500/20 transition-colors">
                    <Github className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider block">Explore source code</span>
                    <span className="text-xs font-mono font-bold text-white mt-1 block">{portfolioOwner.githubUrl.replace('https://', '')}</span>
                  </div>
                </a>

              </div>

              {/* Recruitment Pitch */}
              <div className="pt-4 border-t border-[#222222] text-xs text-gray-400 space-y-2 leading-relaxed">
                <div className="flex items-center space-x-1.5 text-cyan-400 font-bold uppercase tracking-wider text-[10px] font-mono mb-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Recruiter Direct-Hire</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  Sowkath Ali is actively seeking full-time roles as a <strong>Data Scientist</strong>, <strong>ML Engineer</strong>, or <strong>Data Analyst</strong>. Open to global remote opportunities and relocation benefits.
                </p>
              </div>
            </div>
          </div>

          {/* Message Form */}
          <div className="lg:col-span-7" id="contact-form-panel">
            <div className="bg-[#111111] border border-[#222222] rounded-none p-6 sm:p-8 shadow-xl">
              {isSubmitted ? (
                <div className="text-center py-12 space-y-4" id="contact-submit-success">
                  <div className="inline-flex p-4 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 rounded-none mb-2">
                    <CheckCircle className="w-10 h-10 animate-bounce" />
                  </div>
                  <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white">Message Transmitted</h3>
                  <p className="text-xs text-gray-400 max-w-sm mx-auto leading-relaxed">
                    Thank you! Your message has been simulated successfully. For immediate feedback and job offers, feel free to email Sowkath directly at <strong className="text-cyan-400">{portfolioOwner.email}</strong>.
                  </p>
                  <button
                    onClick={() => setIsSubmitted(false)}
                    className="mt-4 px-5 py-2.5 bg-black hover:bg-[#111111] text-white font-mono uppercase tracking-wider text-xs rounded-none border border-[#222222] transition-colors cursor-pointer"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6" id="contact-msg-form">
                  <div className="flex flex-col sm:flex-row gap-6">
                    {/* Name */}
                    <div className="flex-1 space-y-1.5">
                      <label className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block">Full Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="E.g., Sarah Jenkins"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full bg-black border border-[#222222] rounded-none px-4 py-3 text-xs sm:text-sm text-white focus:border-cyan-500 focus:outline-none placeholder-gray-700 font-mono"
                      />
                    </div>

                    {/* Email */}
                    <div className="flex-1 space-y-1.5">
                      <label className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block">Email Address *</label>
                      <input
                        type="email"
                        required
                        placeholder="E.g., sarah@company.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full bg-black border border-[#222222] rounded-none px-4 py-3 text-xs sm:text-sm text-white focus:border-cyan-500 focus:outline-none placeholder-gray-700 font-mono"
                      />
                    </div>
                  </div>

                  {/* Company */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block">Company (Optional)</label>
                    <input
                      type="text"
                      placeholder="E.g., Acme Corp"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      className="w-full bg-black border border-[#222222] rounded-none px-4 py-3 text-xs sm:text-sm text-white focus:border-cyan-500 focus:outline-none placeholder-gray-700 font-mono"
                    />
                  </div>

                  {/* Message */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block">Your Message *</label>
                    <textarea
                      required
                      rows={5}
                      placeholder="Discuss hiring terms, scheduling interviews, technical questions..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full bg-black border border-[#222222] rounded-none px-4 py-3 text-xs sm:text-sm text-white focus:border-cyan-500 focus:outline-none placeholder-gray-700 resize-none font-mono"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full sm:w-auto flex items-center justify-center space-x-2 px-6 py-3 bg-cyan-500 text-black hover:bg-cyan-400 disabled:opacity-50 font-bold text-xs uppercase tracking-wider rounded-none transition-all cursor-pointer"
                    id="contact-submit-btn"
                  >
                    <span>{isSubmitting ? 'Transmitting...' : 'Send Message'}</span>
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
