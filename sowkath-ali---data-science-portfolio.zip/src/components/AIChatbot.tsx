import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, AlertCircle, RefreshCw, HelpCircle } from 'lucide-react';
import { ChatMessage } from '../types';

export default function AIChatbot() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: "Hello! I am Sowkath Ali's AI Representative. I have been trained on his resume, skills, and specifically his Employee Attrition Prediction project. Ask me anything about his qualifications, model methodologies, or suitability for your open data science roles!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const suggestedQuestions = [
    "What are Sowkath's core technical skills?",
    "How does his attrition model resolve class imbalance?",
    "What is the ROC-AUC score of his XGBoost model?",
    "Is Sowkath open to remote/relocation roles?"
  ];

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    setError(null);
    const userMessageText = textToSend;
    setInput('');

    // Append user message
    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: userMessageText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: updatedMessages.map(m => ({
            role: m.role,
            text: m.text
          }))
        }),
      });

      if (!response.ok) {
        throw new Error('Could not retrieve AI response. Verify API key is added in Secrets.');
      }

      const data = await response.json();
      
      const botMessage: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: 'model',
        text: data.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An error occurred while reaching the server.');
      
      // Append a helpful error message to the thread
      const errorResponse: ChatMessage = {
        id: `error-${Date.now()}`,
        role: 'model',
        text: "I'm having trouble connecting to my brain right now. 🧠 This usually happens if the GEMINI_API_KEY environment variable is not set up inside the Secrets panel. Let me provide a brief summary of Sowkath's credentials instead: He is a CSE Graduate specializing in Python ML pipelines (XGBoost, Random Forest), handles unbalanced datasets via SMOTE, and can be emailed directly at sowkath.sow.007@gmail.com!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorResponse]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(input);
  };

  const handleQuestionClick = (question: string) => {
    handleSendMessage(question);
  };

  return (
    <section id="ai-chat" className="py-24 bg-[#050505] border-t border-[#222222] border-x-[8px] border-b-[8px] border-[#1A1A1A] box-border relative">
      {/* Background light rays */}
      <div className="absolute top-1/3 right-1/4 w-[450px] h-[450px] bg-cyan-500/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 left-1/3 w-[350px] h-[350px] bg-blue-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Title */}
        <div className="text-center mb-12" id="chat-section-header">
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-[#111111] border border-[#222222] text-cyan-400 text-[10px] font-mono tracking-widest uppercase mb-3 rounded-none">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Interactive AI Assistant</span>
          </div>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-white tracking-tight uppercase">
            Chat with <span className="text-cyan-400 italic font-mono">Sowkath's AI Co-Pilot</span>
          </h2>
          <p className="text-gray-400 text-xs sm:text-sm mt-2 max-w-xl mx-auto leading-relaxed">
            Have questions about his predictive pipeline, SMOTE, or remote job alignment? Ask his Gemini-powered bot in real-time.
          </p>
        </div>

        {/* Chat Console Structure */}
        <div className="bg-[#111111] border border-[#222222] rounded-none shadow-2xl flex flex-col h-[550px] overflow-hidden" id="chat-console-box">
          
          {/* Console Header */}
          <div className="px-5 py-4 bg-black border-b border-[#222222] flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-cyan-500/10 p-2 rounded-none border border-cyan-500/20">
                <Bot className="w-5 h-5 text-cyan-400" />
              </div>
              <div>
                <h3 className="font-display font-bold text-xs uppercase tracking-wider text-white">Sowkath Ali's AI Co-Pilot</h3>
                <div className="flex items-center space-x-1 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-none bg-cyan-400 animate-ping" />
                  <span className="text-[9px] font-mono text-cyan-400 uppercase tracking-widest">Powered by Gemini 2.5 Flash</span>
                </div>
              </div>
            </div>
            {/* Direct Email Link */}
            <a
              href="mailto:sowkath.sow.007@gmail.com"
              className="text-[10px] font-mono font-bold uppercase tracking-wider text-gray-400 hover:text-white transition-colors bg-[#111111] px-3 py-1.5 rounded-none border border-[#333333]"
              id="chat-direct-email"
            >
              Direct Email
            </a>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-black/40" id="chat-messages-container">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-[85%] ${
                  msg.role === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'
                }`}
                id={`chat-msg-${msg.id}`}
              >
                {/* Avatar Icon */}
                <div className={`p-2 h-9 w-9 rounded-none border shrink-0 flex items-center justify-center ${
                  msg.role === 'user'
                    ? 'bg-blue-500/10 border-blue-500/20 text-blue-400'
                    : 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400'
                }`}>
                  {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                {/* Message Bubble */}
                <div className="space-y-1">
                  <div className={`px-4 py-3 rounded-none text-xs sm:text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-cyan-950 text-white border border-cyan-800/30'
                      : 'bg-[#111111] text-gray-200 border border-[#222222]'
                  }`}>
                    {/* Preserve line breaks for markdown/bullet lists from Gemini */}
                    <p className="whitespace-pre-line font-mono text-xs">{msg.text}</p>
                  </div>
                  <span className="text-[9px] font-mono text-gray-500 block text-right uppercase">
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-3 max-w-[80%] mr-auto" id="chat-loading-indicator">
                <div className="p-2 h-9 w-9 rounded-none bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center">
                  <Bot className="w-4 h-4 animate-spin" />
                </div>
                <div className="bg-[#111111] border border-[#222222] px-4 py-3 rounded-none">
                  <div className="flex items-center space-x-1.5 py-1.5 px-1">
                    <span className="w-2 h-2 rounded-none bg-cyan-400 animate-bounce" />
                    <span className="w-2 h-2 rounded-none bg-cyan-400 animate-bounce [animation-delay:0.2s]" />
                    <span className="w-2 h-2 rounded-none bg-cyan-400 animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Suggested Quick Questions */}
          <div className="px-5 py-2.5 bg-black border-t border-[#222222] overflow-x-auto whitespace-nowrap scrollbar-none flex gap-2" id="chat-suggested-row">
            {suggestedQuestions.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleQuestionClick(q)}
                disabled={isLoading}
                className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-[#111111] border border-[#222222] text-gray-300 hover:text-cyan-400 hover:border-cyan-500/30 rounded-none text-[10px] font-mono uppercase tracking-wider transition-all cursor-pointer disabled:opacity-50"
                id={`suggested-q-${idx}`}
              >
                <HelpCircle className="w-3.5 h-3.5 text-gray-500" />
                <span>{q}</span>
              </button>
            ))}
          </div>

          {/* Input Console Form */}
          <form onSubmit={handleFormSubmit} className="p-4 bg-black border-t border-[#222222] flex gap-3" id="chat-input-form">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about model tuning, SMOTE, skills, resume details..."
              disabled={isLoading}
              className="flex-1 bg-[#111111] border border-[#222222] focus:border-cyan-500 rounded-none px-4 py-3 text-xs sm:text-sm text-white focus:outline-none placeholder-gray-600 disabled:opacity-50 font-mono"
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="bg-cyan-500 text-black p-3 rounded-none hover:bg-cyan-400 disabled:opacity-50 transition-colors cursor-pointer flex items-center justify-center shrink-0 font-bold"
              id="chat-submit-btn"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>

      </div>
    </section>
  );
}
