import React from 'react';
import { ArrowRight, Sparkles, Brain, Database, ChevronDown } from 'lucide-react';
import { portfolioOwner } from '../data';

interface HeroProps {
  setActiveSection: (section: string) => void;
}

export default function Hero({ setActiveSection }: HeroProps) {
  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="relative min-h-[95vh] flex items-center pt-32 pb-16 overflow-hidden bg-[#050505] border-x-[8px] border-t-[8px] border-[#1A1A1A] box-border">
      {/* Background radial highlight */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-cyan-500/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-2/3 right-1/4 w-[300px] h-[300px] bg-blue-500/5 rounded-full blur-[100px] pointer-events-none" />

      {/* Grid lines pattern overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#222222_1px,transparent_1px),linear-gradient(to_bottom,#222222_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_40%,#000_70%,transparent_100%)] opacity-30 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Main Info */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left animate-fade-in" id="hero-main-content">
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-[#111111] border border-[#222222] text-cyan-400 text-[10px] font-mono tracking-[0.25em] uppercase">
              <Sparkles className="w-3 h-3 text-cyan-400" />
              <span>Available for Data Science Roles</span>
            </div>

            <h1 className="font-display font-black text-4xl sm:text-6xl lg:text-[5.5rem] leading-[0.95] tracking-tight uppercase text-white text-left">
              Employee<br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">Attrition</span><br/>
              Prediction
            </h1>

            <p className="font-display text-xs sm:text-sm uppercase tracking-[0.3em] text-cyan-500 font-bold text-left">
              Sowkath Ali // Portfolio & Predictive Pipeline
            </p>

            <p className="text-gray-400 text-sm sm:text-base leading-relaxed max-w-2xl text-left border-l-2 border-cyan-500 pl-6 py-2">
              {portfolioOwner.summary}
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-start gap-4 pt-4">
              <button
                onClick={() => scrollToSection('flagship')}
                className="w-full sm:w-auto flex items-center justify-center space-x-2 px-6 py-4 bg-cyan-500 text-black font-black uppercase tracking-[0.2em] text-xs transition-all hover:bg-cyan-400 active:scale-98 cursor-pointer group rounded-none"
                id="hero-view-project"
              >
                <span>Explore Model</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => scrollToSection('ai-chat')}
                className="w-full sm:w-auto flex items-center justify-center space-x-2 px-6 py-4 bg-[#111111] text-white border border-[#333333] font-bold uppercase tracking-[0.2em] text-xs transition-all hover:bg-[#1a1a1a] cursor-pointer rounded-none"
                id="hero-chat-ai"
              >
                <span>Ask My AI Representative</span>
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-3 gap-4 pt-8 border-t border-[#333333] max-w-lg text-left" id="hero-quick-metrics">
              <div className="bg-[#111111] border border-[#222222] p-4 rounded-none">
                <p className="font-mono text-xl sm:text-2xl font-bold text-cyan-400 italic">89.2%</p>
                <p className="text-[9px] text-gray-500 uppercase tracking-widest mt-1">F1-Score</p>
              </div>
              <div className="bg-[#111111] border border-[#222222] p-4 rounded-none">
                <p className="font-mono text-xl sm:text-2xl font-bold text-white italic">XGBoost</p>
                <p className="text-[9px] text-gray-500 uppercase tracking-widest mt-1">Classifier</p>
              </div>
              <div className="bg-[#111111] border border-[#222222] p-4 rounded-none">
                <p className="font-mono text-xl sm:text-2xl font-bold text-white italic">SMOTE</p>
                <p className="text-[9px] text-gray-500 uppercase tracking-widest mt-1">Resampling</p>
              </div>
            </div>
          </div>

          {/* Graphical Representation Card */}
          <div className="lg:col-span-5 flex justify-center" id="hero-graphics-container">
            <div className="relative w-full max-w-sm bg-[#111111] border border-[#222222] rounded-none p-6 shadow-2xl">
              {/* Card header representing model compiler status */}
              <div className="flex items-center justify-between border-b border-[#222222] pb-4 mb-4">
                <div className="flex items-center space-x-2">
                  <div className="w-2.5 h-2.5 rounded-none bg-red-600" />
                  <div className="w-2.5 h-2.5 rounded-none bg-yellow-600" />
                  <div className="w-2.5 h-2.5 rounded-none bg-cyan-600" />
                </div>
                <span className="font-mono text-[10px] tracking-widest text-gray-500 uppercase">sowkath_attrition_pipeline.py</span>
              </div>

              {/* Code simulation */}
              <div className="space-y-3 font-mono text-[11px] text-gray-300 bg-[#050505] p-4 rounded-none border border-[#222222] leading-relaxed overflow-x-auto">
                <p className="text-cyan-500">import <span className="text-gray-300">pandas</span> as <span className="text-blue-400">pd</span></p>
                <p className="text-cyan-500">from <span className="text-gray-300">sklearn.ensemble</span> import <span className="text-blue-400">RandomForest</span></p>
                <p className="text-cyan-500">from <span className="text-gray-300">imblearn.over_sampling</span> import <span className="text-blue-400">SMOTE</span></p>
                <p className="text-gray-500 mt-2"># HR Minority Class Re-sampling</p>
                <p className="text-gray-400">smote = SMOTE(random_state=42)</p>
                <p className="text-gray-400">X_bal, y_bal = smote.fit_resample(X, y)</p>
                <p className="text-gray-500 mt-2"># Fit Optimized Ensembles</p>
                <p className="text-gray-400">model = XGBClassifier(n_estimators=100)</p>
                <p className="text-cyan-400">model.fit(X_bal, y_bal)</p>
                <p className="text-cyan-400 font-bold mt-2">&gt;&gt;&gt; ROC-AUC: 93.8% // Test F1: 89.2%</p>
              </div>

              {/* Graphical mini indicator */}
              <div className="mt-4 flex gap-3">
                <div className="flex-1 bg-[#050505] border border-[#222222] p-3 rounded-none flex items-center space-x-3">
                  <Brain className="w-4 h-4 text-cyan-400 animate-pulse" />
                  <div>
                    <p className="text-[8px] text-gray-500 uppercase tracking-wider block">Classifier</p>
                    <p className="text-xs font-mono font-bold text-white">XGBoost & RF</p>
                  </div>
                </div>
                <div className="flex-1 bg-[#050505] border border-[#222222] p-3 rounded-none flex items-center space-x-3">
                  <Database className="w-4 h-4 text-blue-400" />
                  <div>
                    <p className="text-[8px] text-gray-500 uppercase tracking-wider block">Resampling</p>
                    <p className="text-xs font-mono font-bold text-white">SMOTE Balancer</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Floating Indicator */}
        <div className="flex justify-center mt-12">
          <button
            onClick={() => scrollToSection('flagship')}
            className="text-gray-500 hover:text-cyan-400 transition-colors flex flex-col items-center cursor-pointer text-[10px] font-mono uppercase tracking-[0.2em]"
            id="hero-scroll-indicator"
          >
            <span>Explore Dashboard</span>
            <ChevronDown className="w-4 h-4 mt-1 animate-bounce" />
          </button>
        </div>
      </div>
    </section>
  );
}
