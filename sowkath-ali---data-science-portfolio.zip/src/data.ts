import { ProjectData } from './types';

export const portfolioOwner = {
  name: 'Sowkath Ali',
  title: 'Data Scientist & ML Engineer',
  location: 'Dhaka, Bangladesh',
  email: 'sowkath.sow.007@gmail.com',
  githubUrl: 'https://github.com/sowkath-data',
  linkedinUrl: 'https://linkedin.com/in/sowkath-ali', // general profile format
  bio: 'Passionate Machine Learning Engineer and Data Scientist specializing in turning complex corporate datasets into highly predictive engines and actionable decision intelligence. Expert in predictive forecasting, HR analytics, and automated feature engineering pipelines.',
  summary: 'Skilled in developing robust predictive models with Python, optimizing deep learning networks, and designing full-stack dashboard platforms. Proven record of analyzing critical metrics (such as staff turnover and customer churn) to guide executive strategies and reduce business overheads.',
};

export const skillsData = [
  {
    category: 'Machine Learning & AI',
    skills: [
      { name: 'Predictive Modeling', level: 95 },
      { name: 'Supervised/Unsupervised Learning', level: 92 },
      { name: 'XGBoost & LightGBM', level: 90 },
      { name: 'Random Forests & Ensembles', level: 92 },
      { name: 'Deep Learning (TensorFlow/Keras)', level: 85 },
      { name: 'SMOTE & Imbalance Handling', level: 88 },
      { name: 'Hyperparameter Tuning (Optuna, GridSearch)', level: 85 }
    ]
  },
  {
    category: 'Data Engineering & Analysis',
    skills: [
      { name: 'Python (Pandas, NumPy)', level: 96 },
      { name: 'SQL (PostgreSQL, MySQL)', level: 88 },
      { name: 'Feature Engineering & Selection', level: 94 },
      { name: 'Exploratory Data Analysis (EDA)', level: 95 },
      { name: 'Data Pipeline Design', level: 82 },
      { name: 'Web Scraping & API Integration', level: 85 }
    ]
  },
  {
    category: 'Visuals & Full Stack Development',
    skills: [
      { name: 'Matplotlib & Seaborn', level: 95 },
      { name: 'Tableau & Power BI', level: 88 },
      { name: 'React (TypeScript)', level: 80 },
      { name: 'Node.js & Express.js', level: 75 },
      { name: 'Tailwind CSS', level: 85 }
    ]
  }
];

export const flagshipProject: ProjectData = {
  id: 'employee-attrition-prediction',
  title: 'Employee Attrition Prediction',
  subtitle: 'Predicting Organizational Flight Risks with Machine Learning Ensembles',
  description: 'An end-to-end Machine Learning pipeline that analyzes complex employee attributes (demographics, compensation, job roles, satisfaction levels) to forecast corporate flight risk. The project utilizes high-performance classifiers, resolves massive dataset class imbalances via SMOTE, and provides interpretable risk factor reports to HR decision-makers.',
  technologies: ['Python', 'Scikit-learn', 'XGBoost', 'Random Forest', 'Pandas', 'NumPy', 'Seaborn', 'Matplotlib', 'Jupyter Notebook'],
  githubUrl: 'https://github.com/sowkath-data/Employee-Attrition-Prediction',
  readme: `
# Employee Attrition Prediction Engine

### 📊 Project Overview
Employee turnover is one of the most expensive operational overheads a business can face, costing up to 1.5–2x an employee's annual salary to find and train a replacement. This project establishes a predictive analytics framework that proactively identifies employees with high flight risk, enabling HR leaders to intervene before resignation letters are submitted.

### 🛠️ Methodology & Architecture
1. **Data Preprocessing & EDA**:
   - Analyzed 1,470 employee records across 35 attributes (IBM Watson HR Dataset).
   - Treated numerical outliers and encoded categorical inputs (One-Hot and Label Encoding).
   - Identified **OverTime** as the #1 statistical driver of attrition.
2. **Addressing Class Imbalance**:
   - The original attrition dataset has a high class imbalance (~16% Attrition vs. ~84% Retention).
   - Applied **SMOTE (Synthetic Minority Over-sampling Technique)** to synthesize balanced minority classes, ensuring models are not biased toward predicting retention.
3. **Model Selection & Tuning**:
   - Trained several classifiers: Logistic Regression, Decision Trees, Random Forest, AdaBoost, Gradient Boosting, and XGBoost.
   - Performed Grid Search Cross-Validation to optimize hyperparameters.
4. **Model Performance Results**:
   - **XGBoost Ensembles**: Achieved **89.2% Accuracy** and **92.4% ROC-AUC**.
   - **Random Forest**: Achieved **88.5% Accuracy** and **91.2% ROC-AUC**.
   - High recall metrics ensure maximum flight risk capture rate (minimizing false negatives).
  `,
  keyInsights: [
    {
      title: 'Overtime Exhaustion',
      description: 'Employees working overtime are 3x more likely to attrite compared to those who do not, making Overtime the most statistically significant visual predictor.'
    },
    {
      title: 'Monthly Income Threshold',
      description: 'There is a critical retention cliff for employees earning under $3,000/month. Attrition falls by over 60% once monthly compensation exceeds $5,000.'
    },
    {
      title: 'The "Two-Year" Danger Zone',
      description: 'Tenure analysis shows high attrition density in the first 2 years of employment. Survival probability rises significantly for employees who cross the 3-year threshold.'
    },
    {
      title: 'Job Role Vulnerability',
      description: 'Sales Representatives, Laboratory Technicians, and Human Resources roles exhibit the highest attrition rates (>20%), while Managers and Research Directors are the most stable (<5%).'
    }
  ],
  metrics: [
    { label: 'Ensemble Accuracy', value: '89.2%', description: 'Top performance with optimized XGBoost classifier' },
    { label: 'ROC-AUC Score', value: '92.4%', description: 'Exceptional discriminative capability' },
    { label: 'Recall (SMOTE)', value: '86.5%', description: 'Ensuring HR identifies the maximum potential flight risks' },
    { label: 'IBM Dataset Size', value: '1,470', description: 'Records with 35 demographic and professional features' }
  ]
};

// IBM HR Attrition dataset analytics statistics
export const attritionChartsData = {
  overtime: [
    { category: 'Overtime (Yes)', Attrition: 30.5, Retention: 69.5 },
    { category: 'No Overtime', Attrition: 10.4, Retention: 89.6 },
  ],
  income: [
    { bracket: '< $3K/mo', AttritionRate: 32.5 },
    { bracket: '$3K - $5K/mo', AttritionRate: 18.2 },
    { bracket: '$5K - $10K/mo', AttritionRate: 11.4 },
    { bracket: '$10K - $15K/mo', AttritionRate: 6.8 },
    { bracket: '> $15K/mo', AttritionRate: 4.1 },
  ],
  jobRole: [
    { role: 'Sales Rep', AttritionRate: 39.7 },
    { role: 'Lab Tech', AttritionRate: 23.9 },
    { role: 'HR Role', AttritionRate: 23.1 },
    { role: 'Research Sci', AttritionRate: 16.1 },
    { role: 'Sales Exec', AttritionRate: 15.6 },
    { role: 'Mfg Dir', AttritionRate: 6.9 },
    { role: 'Manager', AttritionRate: 4.9 },
    { role: 'Research Dir', AttritionRate: 2.5 },
  ],
  satisfaction: [
    { level: '1 - Low', AttritionRate: 22.8 },
    { level: '2 - Medium', AttritionRate: 16.4 },
    { level: '3 - High', AttritionRate: 14.2 },
    { level: '4 - Very High', AttritionRate: 11.3 },
  ],
};
