export interface PredictorInputs {
  age: number;
  monthlyIncome: number;
  overTime: 'Yes' | 'No';
  jobSatisfaction: number; // 1 to 4
  workLifeBalance: number; // 1 to 4
  yearsAtCompany: number;
  jobRole: string;
  department: string;
  stockOptionLevel: number; // 0 to 3
  totalWorkingYears: number;
  businessTravel: 'Non-Travel' | 'Travel_Rarely' | 'Travel_Frequently';
}

export interface RiskFactor {
  factor: string;
  impact: 'High' | 'Medium' | 'Low';
  type: 'Positive' | 'Negative'; // Positive helps retain, Negative drives attrition
  description: string;
}

export interface PredictorResult {
  probability: number; // 0 to 100
  riskCategory: 'Low' | 'Medium' | 'High';
  recommendations: string[];
  factors: RiskFactor[];
}

export interface ProjectData {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  technologies: string[];
  githubUrl: string;
  readme: string;
  keyInsights: {
    title: string;
    description: string;
  }[];
  metrics: {
    label: string;
    value: string;
    description: string;
  }[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}
