import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ProjectDetail from './components/ProjectDetail';
import Skills from './components/Skills';
import AIChatbot from './components/AIChatbot';
import Contact from './components/Contact';
import { portfolioOwner } from './data';
import { BrainCircuit, Github, Mail, Sparkles, Copyright } from 'lucide-react';

export default function App() {
  const [activeSection, setActiveSection] = useState('home');

  // IntersectionObserver to sync the active nav item with actual scroll position
  useEffect(() => {
    const sections = ['home', 'flagship', 'skills', 'ai-chat', 'contact'];
    
    const handleScrollObserver = () => {
      const scrollPosition = window.scrollY + 200; // Offset for header height and threshold
      
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScrollObserver);
    return () => window.removeEventListener('scroll', handleScrollObserver);
  }, []);

  return (
    <div className="bg-[#070b13] min-h-screen text-slate-100 selection:bg-emerald-500/30 selection:text-emerald-300" id="app-root-container">
      {/* Dynamic Navigation Header */}
      <Header activeSection={activeSection} setActiveSection={setActiveSection} />

      {/* Hero Intro */}
      <Hero setActiveSection={setActiveSection} />

      {/* Flagship Project Attrition Dashboard / Simulator */}
      <ProjectDetail />

      {/* Technical Competencies matrix */}
      <Skills />

      {/* AI Recruiter Agent (Gemini Chat) */}
      <AIChatbot />

      {/* Contact Panel */}
      <Contact />

      {/* Footer */}
      <footer className="bg-[#05070d] border-t border-slate-900/60 py-12" id="portfolio-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            
            {/* Branding */}
            <div className="flex items-center space-x-3 text-left">
              <div className="bg-emerald-500/10 p-2 rounded-lg border border-emerald-500/20 text-emerald-400">
                <BrainCircuit className="w-5 h-5" />
              </div>
              <div>
                <p className="font-display font-bold text-sm text-white">{portfolioOwner.name}</p>
                <p className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest mt-0.5">Data Scientist Portfolio</p>
              </div>
            </div>

            {/* Footer Bio */}
            <p className="text-center md:text-left text-xs text-slate-500 max-w-sm leading-relaxed">
              Premium reactive developer portfolio featuring live machine learning attrition forecasts and an integrated Gemini recruiter chat proxy.
            </p>

            {/* Copyright / Links */}
            <div className="flex flex-col items-center md:items-end gap-3 text-xs text-slate-500">
              <div className="flex space-x-4">
                <a
                  href={portfolioOwner.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-emerald-400 transition-colors"
                >
                  GitHub
                </a>
                <a
                  href={`mailto:${portfolioOwner.email}`}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Email Contact
                </a>
              </div>
              <div className="flex items-center space-x-1 font-mono text-[10px] text-slate-600">
                <Copyright className="w-3 h-3" />
                <span>2026 {portfolioOwner.name}. Built with React, Tailwind & Gemini AI.</span>
              </div>
            </div>

          </div>
        </div>
      </footer>
    </div>
  );
}
